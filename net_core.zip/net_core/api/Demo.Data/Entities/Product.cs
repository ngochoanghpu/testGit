﻿using Demo.Data.Abstracts;
using Demo.Data.Interfaces;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Demo.Data.Entities
{
    public class Product : DomainEntity<int>, ITracking
    {
        public string Name { get; set; }
        
        [Column(TypeName = "VARCHAR")]
        public string Code { get; set; }

        public string Description { get; set; }

        public string Link { get; set; }

        public decimal Price { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string CreatedBy { get; set; }

        public string UpdatedBy { get; set; }

        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category Category { get; set; } //Navigation Property

        public Product()
        {

        }

        public Product(int cateId)
        {
            CategoryId = cateId;
        }
    }
}
