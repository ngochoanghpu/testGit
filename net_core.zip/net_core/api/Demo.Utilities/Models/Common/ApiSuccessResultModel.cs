﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Models.Common
{
    public class ApiSuccessResultModel<T> : ApiResultModel<T>
    {
        public ApiSuccessResultModel(T resultObj)
        {
            IsSuccessed = true;
            ResultObj = resultObj;
        }

        public ApiSuccessResultModel()
        {
            IsSuccessed = true;
        }
    }
}
