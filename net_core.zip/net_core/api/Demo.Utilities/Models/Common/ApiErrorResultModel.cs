﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Models.Common
{
    public class ApiErrorResultModel<T> : ApiResultModel<T>
    {
        public ApiErrorResultModel()
        {
        }

        public ApiErrorResultModel(string message)
        {
            IsSuccessed = false;
            Message = message;
        }
    }
}
