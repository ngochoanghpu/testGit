﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Constants
{
    public class CommonConstants
    {
        public const string ResponseData = "ResponseData";

        public const string CategoryMemoryCache = "CategoryMemoryCache";

        public const string CategoryRedisCache = "CategoryRedisCache";

        public const string Authorization = "Authorization";

        public const string BasicSchema = "Basic";

        public const string BearerSchema = "Bearer";

        public const string Admin = "Admin";

        public const string User = "User";

        public const string Guest = "Guest";
    }
}
