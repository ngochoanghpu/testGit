﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Constants
{
    public class ClaimConstants
    {
        public const string Permission = "Permission";

        public const string UserId = "Id";

        public const string UserName = "UserName";

        public const string Email = "Email";

        public const string Role = "Role";
    }
}
