﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Constants
{
    public class RoleConstants
    {
        public const string AdminRole = "Admin";

        public const string UserRole = "User";

        public const string GuestRole = "Guest";
    }
}
