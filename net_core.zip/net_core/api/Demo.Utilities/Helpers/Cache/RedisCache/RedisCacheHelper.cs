﻿using Microsoft.Extensions.Configuration;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Utilities.Helpers.Cache.RedisCache
{
    public class RedisCacheHelper : IRedisCacheHelper
    {
        private readonly IDatabase _database;
        public RedisCacheHelper(IDatabase database)
        {
            _database = database;
        }

        public async Task<bool> SetValue(string value, string key)
        {
            var result = await _database.StringSetAsync(key, value);

            return result;
        }

        public async Task<string> GetValue(string key)
        {
            var result = string.Empty;

            var redisValue = await _database.StringGetAsync(key);

            if (redisValue.HasValue)
            {
                result = redisValue.ToString();
            }

            return result;
        }

        public async Task<bool> DeleteKey(string key)
        {
            var result = await _database.KeyDeleteAsync(key);

            return result;
        }

        public async Task<bool> IsExistKey(string key)
        {
            var redisValue = await _database.StringGetAsync(key);

            return redisValue.HasValue;
        }
    }
}
