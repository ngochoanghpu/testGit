﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Utilities.Helpers.Cache.RedisCache
{
    public interface IRedisCacheHelper
    {
        Task<bool> SetValue(string key, string value);

        Task<string> GetValue(string key);

        Task<bool> DeleteKey(string key);

        Task<bool> IsExistKey(string key);
    }
}
