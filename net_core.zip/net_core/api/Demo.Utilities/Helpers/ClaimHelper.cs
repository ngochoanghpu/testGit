﻿using Demo.Utilities.Constants;
using Demo.Utilities.Models.Login;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using static Demo.Utilities.Enums.Enums;

namespace Demo.Utilities.Helpers
{
    public static class ClaimHelper
    {
        public static List<Claim> SetClaims(string username)
        {
            var claims = new List<Claim>();

            switch (username)
            {
                case CommonConstants.Admin:
                    claims = new List<Claim>()
                    {
                        new Claim(ClaimConstants.UserId, ((int)UserType.Admin).ToString()),
                        new Claim(ClaimConstants.UserName, CommonConstants.Admin),
                        new Claim(ClaimConstants.Role, RoleConstants.AdminRole)
                     };
                    break;

                case CommonConstants.User:
                    claims = new List<Claim>()
                    {
                        new Claim(ClaimConstants.UserId, ((int)UserType.User).ToString()),
                        new Claim(ClaimConstants.UserName, CommonConstants.User),
                        new Claim(ClaimConstants.Role, RoleConstants.UserRole)
                     };
                    break;

                default:
                    claims = new List<Claim>()
                    {
                        new Claim(ClaimConstants.UserId, ((int)UserType.Guest).ToString()),
                        new Claim(ClaimConstants.UserName, CommonConstants.Guest),
                        new Claim(ClaimConstants.Role, RoleConstants.GuestRole)
                     };
                    break;
            }

            return claims;
        }

        public static bool IsValidUser(LoginModel request)
        {
            if (request.UserName != CommonConstants.Admin &&
                 request.UserName != CommonConstants.User &&
                 request.UserName != CommonConstants.Guest
                )
            {
                return false;
            }

            if (request.Password != "123456")
            {
                return false;
            }

            return true;
        }
    }
}
