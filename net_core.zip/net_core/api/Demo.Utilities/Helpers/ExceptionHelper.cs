﻿using Demo.Utilities.Constants;
using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Exceptions;
using Demo.Utilities.Models.Common;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using static Demo.Utilities.Enums.Enums;

namespace Demo.Utilities.Helpers
{
    public class ExceptionHelper
    {
        public static object GetResponseData(Exception ex)
        {
            var responseData = ex.Data[CommonConstants.ResponseData];

            return responseData;
        }

        public static bool IsCustomException(Exception ex)
        {
            if (IsBadRequestException(ex) || IsNotFoundException(ex))
            {
                return true;
            }

            return false;
        }

        public static bool IsCustomException(ExceptionType type)
        {
            if (type == ExceptionType.NotFoundException || type == ExceptionType.BadRequestException)
            {
                return true;
            }

            return false;
        }

        public static bool IsBadRequestException(Exception ex)
        {
            if (ex.GetType().Name == nameof(BadRequestException))
            {
                return true;
            }

            return false;
        }

        public static bool IsNotFoundException(Exception ex)
        {
            if (ex.GetType().Name == nameof(NotFoundException))
            {
                return true;
            }

            return false;
        }

        public static Exception GetExceptionType(ExceptionType type)
        {
            switch (type)
            {
                case ExceptionType.BadRequestException:
                    return new BadRequestException();

                case ExceptionType.NotFoundException:
                    return new NotFoundException();

                default:
                    return new Exception();
            }

        }

        public static Exception SetException(string message, ExceptionType type)
        {
            dynamic result = new
            {
                IsSuccessed = false,
                Message = message,
                ResultObj = (object)null
            };

            var exception = GetExceptionType(type);
            exception.Data.Add(CommonConstants.ResponseData, result);

            return exception;
        }

        public static void ThrowException(string message, ExceptionType type)
        {
            var exception = SetException(message, type);

            throw exception;
        }

        public static void ThrowException(Exception ex)
        {
            if (IsCustomException(ex))
            {
                throw ex;
            }

            ThrowException(ex.Message, ExceptionType.InternalServerException);
        }
    }

    public class BaseException<T>
    {
        public static Exception SetException(string message, ExceptionType type)
        {
            var result = new ApiErrorResultModel<T>(message);

            var exception = ExceptionHelper.GetExceptionType(type);
            exception.Data.Add(CommonConstants.ResponseData, result);

            return exception;
        }

        public static void ThrowException(string message, ExceptionType type)
        {
            var exception = SetException(message, type);

            throw exception;
        }
    }
}
