﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Exceptions
{
    [Serializable]
    public class BadRequestException : SystemException
    {
        public BadRequestException() { }

        public BadRequestException(string message) : base(message)
        {

        }
    }
}
