﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Exceptions
{
    [Serializable]
    public class NotFoundException : SystemException
    {
        public NotFoundException() { }

        public NotFoundException(string message) : base(message)
        {

        }
    }
}
