﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Exceptions
{
    public class BaseBadRequestException<T> : BadRequestException
    {
        //public BaseBadRequestException() { }

        //public BaseBadRequestException(string message) : base(message)
        //{

        //}
    }
}
