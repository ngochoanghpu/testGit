﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Utilities.Enums
{
    public class Enums
    {
        public enum ExceptionType
        {
            BadRequestException,

            NotFoundException,

            InternalServerException
        }

        public enum UserType
        {
            Admin = 1,
            User = 2,
            Guest = 3
        }
    }
}
