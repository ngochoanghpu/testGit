﻿using Demo.Infrastructure.Repositories.Category;
using Demo.Infrastructure.Repositories.Product;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Infrastructure.UoW
{
    public interface IUnitOfWork : IDisposable
    {
        ICategoryRepository CategoryRepository { get; set; }

        IProductRepository ProductRepository { get; set; }

        DataSet ExecuteSp(string procName, params SqlParameter[] paramters);

        Task Commit();
    }
}
