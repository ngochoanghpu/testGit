﻿using Demo.Data.EF;
using Demo.Infrastructure.Repositories.Category;
using Demo.Infrastructure.Repositories.Product;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection.Metadata;

namespace Demo.Infrastructure.UoW
{
    public class EFUnitOfWork : IUnitOfWork
    {
        private readonly DemoContext _context;

        public ICategoryRepository CategoryRepository { get; set; }
        public IProductRepository ProductRepository { get; set; }

        public EFUnitOfWork(DemoContext context,
                            ICategoryRepository categoryRepository,
                            IProductRepository productRepository)
        {
            _context = context;
            CategoryRepository = categoryRepository;
            ProductRepository = productRepository;
        }

        public async Task Commit()
        {
            await _context.SaveChangesAsync();
        }

        public DataSet ExecuteSp(string procName, params SqlParameter[] paramters)
        {
            DataSet result = new DataSet();
            var connection = _context.Database.GetDbConnection();

            using (var command = connection.CreateCommand())
            {
                using (DbDataAdapter adapter = DbProviderFactories.GetFactory(connection).CreateDataAdapter())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = procName;

                    if (paramters != null && paramters.Any())
                    {
                        command.Parameters.AddRange(paramters);
                    }

                    adapter.SelectCommand = command;
                    adapter.Fill(result);
                }
            }

            return result;

        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
