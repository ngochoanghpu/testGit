﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Infrastructure.Repositories.Category
{
    public interface ICategoryRepository : IRepository<Data.Entities.Category, int>
    {
       
    }
}
