﻿using Demo.Data.EF;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Infrastructure.Repositories.Category
{
    public class CategoryRepository : EFRepository<Data.Entities.Category, int>, ICategoryRepository
    {
        public CategoryRepository(DemoContext context) : base(context) { }
    }
}
