﻿using Demo.Data.EF;
using Demo.Infrastructure.Repositories.Category;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Infrastructure.Repositories.Product
{
    public class ProductRepository : EFRepository<Data.Entities.Product, int>, IProductRepository
    {
        public ProductRepository(DemoContext context) : base(context) { }
    }
}
