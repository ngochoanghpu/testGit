﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Infrastructure.Repositories.Product
{
    public interface IProductRepository : IRepository<Data.Entities.Product, int>
    {
    }
}
