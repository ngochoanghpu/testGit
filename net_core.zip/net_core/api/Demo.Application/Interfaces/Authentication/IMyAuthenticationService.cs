﻿using Demo.Utilities.Dtos;
using Demo.Utilities.Models.Common;
using Demo.Utilities.Models.Login;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Application.Interfaces.Authentication
{
    public interface IMyAuthenticationService
    {
        Task<ApiResultModel<string>> Authenticate(LoginModel request);
    }
}
