﻿using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Dtos.Product;
using Demo.Utilities.Models.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Application.Interfaces.Product
{
    public interface IProductService
    {
        Task<ApiResultModel<int>> AddProduct(ProductDto productDto);

        Task<ApiResultModel<List<ProductDto>>> GetProducts();

        Task<ApiResultModel<List<ProductDto>>> GetProductsWithRawSql();

        Task<ApiResultModel<List<ProductProjectDto>>> GetProductsByProjectTo();

        Task<ApiResultModel<ProductProjectDto>> GetProductById(int id);

        Task<ApiResultModel<ProductDto>> GetProductRawSqlById(int id);
    }
}
