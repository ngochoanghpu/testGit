﻿using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Models.Common;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Demo.Application.Interfaces.Category
{
    public interface ICategoryService
    {
        Task<ApiResultModel<List<CategoryDto>>> GetCategories();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_v2();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_v3();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_v4();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Left_Join();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Navigation_Property();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_IQueryable();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_IEnumerable();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_ToList();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Lazy_Loading();

        Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Inner_Join();

        Task<ApiResultModel<List<CategoryDto>>> GetCategoriesWithEagerLoading();

        Task<ApiResultModel<List<CategoryDto>>> GetCategoriesWithExpicitLoading();

        Task<ApiResultModel<bool>> UsingTransactionScope();

        Task<ApiResultModel<bool>> UsingTransactionIsolationLevel();

        Task<ApiResultModel<CategoryDto>> UsingTransactionReadUncommited();

        Task<ApiResultModel<bool>> UsingTransactionReadCommited();

        Task<ApiResultModel<int>> AddCategory(CategoryDto category);

        Task<ApiResultModel<int>> AddCategory_v2(CategoryDto category);

        Task<ApiResultModel<bool>> DeleteCategory(int id);

        Task<ApiResultModel<bool>> DeleteCategory_v2(int id);

        Task<ApiResultModel<bool>> UpdateCategory(CategoryDto category);

        Task<ApiResultModel<bool>> UpdateCategory_v2(CategoryDto category);

        Task<ApiResultModel<CategoryDto>> GetCategoryById(int id);

        Task<ApiResultModel<CategoryDto>> GetCategoryById_v2(int categoryId);

        Task<ApiResultModel<CategoryDto>> GetCategoryById_v3(int categoryId);

        Task<ApiResultModel<CategoryDto>> GetCategoryById_v4(int categoryId);

        Task<ApiResultModel<int>> AddCategoryWithoutTransaction(CategoryDto category);
    }
}