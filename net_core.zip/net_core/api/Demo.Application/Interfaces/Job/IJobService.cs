﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Application.Interfaces.Job
{
    public interface IJobService
    {
        Task SendSms();
    }
}
