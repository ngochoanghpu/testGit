﻿using AutoMapper;
using Demo.Data.Entities;
using Demo.Utilities.Dtos.Product;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Application.AutoMapper
{
    public class DtoToDomainMappingProfile : Profile
    {
        public DtoToDomainMappingProfile()
        {
            CreateMap<ProductDto, Product>()
                .ForMember(x => x.Id, opt => opt.Ignore())
                .ConstructUsing(p => new Product(p.CateId));
        }
    }
}
