﻿using AutoMapper;
using Demo.Data.Entities;
using Demo.Utilities.Dtos.Product;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Application.AutoMapper
{
    public class DomainToDtoMappingProfile : Profile
    {
        public DomainToDtoMappingProfile()
        {
            CreateMap<Product, ProductDto>()
                .ConstructUsing(p => new ProductDto(p.CategoryId, p.Price));


            CreateMap<Product, ProductProjectDto>()
               .ForMember(dest => dest.CateId, opt => opt.MapFrom(p => p.CategoryId))
               .ForMember(dest => dest.Price, opt => opt.MapFrom(p => (double)p.Price));
        }
    }
}
