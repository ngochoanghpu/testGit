﻿using Demo.Application.Interfaces.Category;
using Demo.Data.EF;
using Demo.Infrastructure.UoW;
using Demo.Utilities.Constants;
using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Helpers;
using Demo.Utilities.Helpers.Cache.RedisCache;
using Demo.Utilities.Models.Common;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using static Demo.Utilities.Enums.Enums;
using IsolationLevel = System.Data.IsolationLevel;

namespace Demo.Application.Implementation.Category
{
    public class CategoryService : ICategoryService
    {
        private readonly IUnitOfWork _unitOfWork;

        private readonly IMemoryCache _memoryCache;

        private readonly IRedisCacheHelper _redisCacheHelper;

        private readonly IServiceProvider _serviceProvider;

        private readonly DemoContext _dbContext;

        private readonly ILogger<CategoryService> _logger;

        public CategoryService(IUnitOfWork unitOfWork,
                               IServiceProvider serviceProvider,
                               DemoContext dbContext,
                               ILogger<CategoryService> logger,
                               IMemoryCache memoryCache,
                               IRedisCacheHelper redisCacheHelper)
        {
            _unitOfWork = unitOfWork;
            _serviceProvider = serviceProvider;
            _dbContext = dbContext;
            _memoryCache = memoryCache;
            _redisCacheHelper = redisCacheHelper;
            _logger = logger;
        }

        public async Task<ApiResultModel<int>> AddCategory(CategoryDto category)
        {
            var result = new ApiResultModel<int>();

            try
            {
                var categoryId = await AddCategoryWithTransactionByOnlySaveChange(category);

                result = new ApiSuccessResultModel<int>(categoryId);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<int>(ex.Message);
            }

            return result;
        }

        public async Task<ApiResultModel<int>> AddCategoryWithoutTransaction(CategoryDto category)
        {
            var result = new ApiResultModel<int>();

            try
            {
                var categoryId = await DoAddCategoryWithoutTransaction(category);

                result = new ApiSuccessResultModel<int>(categoryId);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<int>(ex.Message);
            }

            return result;
        }

        public async Task<ApiResultModel<bool>> UsingTransactionScope()
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                // update Category
                var categoryEntity = _unitOfWork.CategoryRepository.FindAll(c => c.Id == 7).FirstOrDefault(); //tracking by EF
                if (categoryEntity != null)
                {
                    categoryEntity.Name = "testing";
                    await _unitOfWork.Commit();
                }

                // add more product
                var product = new Data.Entities.Product
                {
                    Name = $"ttt_{DateTime.Now}",
                    CategoryId = categoryEntity.Id
                };

                _unitOfWork.ProductRepository.Add(product);
                await _unitOfWork.Commit();

                // Đánh dấu transaction đã thành công
                scope.Complete();
            }

            var result = new ApiSuccessResultModel<bool>(true);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<bool>> UsingTransactionIsolationLevel()
        {
            using (var transaction = _dbContext.Database.BeginTransaction(IsolationLevel.ReadUncommitted))
            {
                try
                {
                    // update Category
                    var categoryEntity = _unitOfWork.CategoryRepository.FindAll(c => c.Id == 24).FirstOrDefault();
                    if (categoryEntity != null)
                    {
                        categoryEntity.Name = "testing_v3";
                        await _unitOfWork.Commit();
                    }

                    // add more product
                    var product = new Data.Entities.Product
                    {
                        Name = $"ttt_{DateTime.Now}",
                        CategoryId = categoryEntity.Id
                    };

                    _unitOfWork.ProductRepository.Add(product);
                    await _unitOfWork.Commit();

                    // Commit transaction
                    transaction.Commit();

                    var result = new ApiSuccessResultModel<bool>(true);

                    return await Task.FromResult(result);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Ocurred error: {ex.Message}");

                    // Rollback transaction nếu có lỗi xảy ra
                    transaction.Rollback();

                    var result = new ApiErrorResultModel<bool>(ex.Message);

                    return await Task.FromResult(result);
                }
            }
        }

        public async Task<ApiResultModel<CategoryDto>> UsingTransactionReadUncommited()
        {
            //using (var transaction = _dbContext.Database.BeginTransaction(IsolationLevel.ReadUncommitted))
            using (var scope = new TransactionScope(TransactionScopeOption.Required,
                        new TransactionOptions()
                        {
                            IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted
                        },
                        TransactionScopeAsyncFlowOption.Enabled))
            {

                var categoryDto = _unitOfWork.CategoryRepository.FindAll(c => c.Id == 24)
                                                                    .Select(c => new CategoryDto
                                                                    {
                                                                        Id = c.Id,
                                                                        Name = c.Name,
                                                                        ProductName = c.Productions.Select(p => p.Name).ToList()
                                                                    }).FirstOrDefault();

                var result = new ApiSuccessResultModel<CategoryDto>(categoryDto);

                return await Task.FromResult(result);
            }
        }

        public async Task<ApiResultModel<bool>> UsingTransactionReadCommited()
        {
            using (var scope1 = new TransactionScope(TransactionScopeOption.Required,
                        new TransactionOptions()
                        {
                            IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted
                        },
                        TransactionScopeAsyncFlowOption.Enabled))
            {                
                var categoryEntity = _unitOfWork.CategoryRepository.FindAll(c => c.Id == 24).FirstOrDefault();
                if (categoryEntity != null)
                {
                    categoryEntity.Name = $"hoang_______{DateTime.Now.Ticks}";
                    await _unitOfWork.Commit();
                }

                var categoryDto = _unitOfWork.CategoryRepository.FindAll(c => c.Id == 24)
                                                                  .Select(c => new CategoryDto
                                                                  {
                                                                      Id = c.Id,
                                                                      Name = c.Name,
                                                                      ProductName = c.Productions.Select(p => p.Name).ToList()
                                                                  }).FirstOrDefault();

                //scope1.Complete();

                var result = new ApiSuccessResultModel<bool>(true);

                return result;
            }
        }

        private async Task<int> DoAddCategoryWithoutTransaction(CategoryDto categoryDto)
        {
            // add category
            var categoryEntity = new Data.Entities.Category()
            {
                Name = categoryDto.Name
            };

            _unitOfWork.CategoryRepository.Add(categoryEntity);
            await _unitOfWork.Commit();

            var categoryId = categoryEntity.Id;

            // add products
            var products = new List<Data.Entities.Product>();
            foreach(var productName in categoryDto.ProductName)
            {
                var productEntity = new Data.Entities.Product()
                {
                    CategoryId = categoryId,
                    Name = productName
                };

                products.Add(productEntity);
            }

            _unitOfWork.ProductRepository.AddRange(products);
            await _unitOfWork.Commit();

            return categoryId;
        }

        private async Task<int> AddCategoryWithTransactionByOnlySaveChange(CategoryDto categoryDto)
        {
            // list product
            var products = new List<Data.Entities.Product>();
            foreach (var productName in categoryDto.ProductName)
            {
                var productEntity = new Data.Entities.Product()
                {
                    Name = productName
                };

                products.Add(productEntity);
            }

            // add category
            var categoryEntity = new Data.Entities.Category() //graph object <> fatten object
            {
                Name = categoryDto.Name,
                Productions = products
            };

            _unitOfWork.CategoryRepository.Add(categoryEntity);
            await _unitOfWork.Commit();

            var categoryId = categoryEntity.Id;

            return categoryId;
        }

        public async Task<ApiResultModel<int>> AddCategory_v2(CategoryDto category)
        {
            var result = new ApiResultModel<int>();

            try
            {
                var parameters = new List<SqlParameter>()
                {
                    new SqlParameter
                    {
                        ParameterName = "@name",
                        SqlDbType = SqlDbType.NVarChar,
                        Value = category.Name,
                        Direction = ParameterDirection.Input
                    },
                    new SqlParameter
                    {
                        ParameterName = "@categoryId",
                        SqlDbType = SqlDbType.Int,
                        Value = category.Name,
                        Direction = ParameterDirection.Output
                    }
                };                

                _unitOfWork.ExecuteSp("sp_add_category", parameters.ToArray());

                var categoryId = Convert.ToInt32(parameters.FirstOrDefault(x => x.ParameterName == "@categoryId").Value);

                result = new ApiSuccessResultModel<int>(categoryId);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<int>(ex.Message);
            }

            return await Task.FromResult(result); ;
        }

        public async Task<ApiResultModel<bool>> UpdateCategory(CategoryDto category)
        {
            var result = new ApiResultModel<bool>();

            try
            {
                var categoryId = category.Id;

                if (categoryId <= 0)
                {
                    var errorMessage = $"Id: {categoryId} is invalid";
                    ExceptionHelper.ThrowException(errorMessage, ExceptionType.BadRequestException);
                }

                var categoryEntity = await _unitOfWork.CategoryRepository.FindByIdAsync(categoryId);
                //var categoryEntity2 = _unitOfWork.CategoryRepository.FindAll(x => x.Id == categoryId).FirstOrDefault();
                if (categoryEntity != null)
                {
                    categoryEntity.Name = category.Name;

                    await _unitOfWork.Commit();

                    result = new ApiSuccessResultModel<bool>(true);
                }
                else
                {
                    var errorMessage = $"Id: {categoryId} is not found";
                    ExceptionHelper.ThrowException(errorMessage, ExceptionType.NotFoundException);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.ThrowException(ex);
            }

            return result;
        }

        public async Task<ApiResultModel<bool>> UpdateCategory_v2(CategoryDto category)
        {
            var result = new ApiResultModel<bool>();

            try
            {
                var parameters = new List<SqlParameter>()
                {
                    new SqlParameter
                    {
                        ParameterName = "@name",
                        SqlDbType = SqlDbType.NVarChar,
                        Value = category.Name,
                        Direction = ParameterDirection.Input
                    },
                    new SqlParameter
                    {
                        ParameterName = "@categoryId",
                        SqlDbType = SqlDbType.Int,
                        Value = category.Id,
                        Direction = ParameterDirection.Input
                    }
                };

                _unitOfWork.ExecuteSp("sp_updateCategory", parameters.ToArray());

                result = new ApiSuccessResultModel<bool>(true);
            }
            catch (Exception ex)
            {
                ExceptionHelper.ThrowException(ex);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<bool>> DeleteCategory(int id)
        {
            var result = new ApiResultModel<bool>();

            try
            {
                var categoryEntity = _unitOfWork.CategoryRepository.FindAll(x => x.Id == id).FirstOrDefault();
                if (categoryEntity != null)
                {
                    _unitOfWork.CategoryRepository.Remove(categoryEntity);

                    await _unitOfWork.Commit();

                    result = new ApiSuccessResultModel<bool>(true);
                }
                else
                {
                    var errorMessage = $"Id: {id} is not found";
                    var exception = BaseException<bool>.SetException(errorMessage, ExceptionType.NotFoundException);
                    throw exception;
                }
            }
            catch (Exception ex)
            {
                if (ExceptionHelper.IsCustomException(ex))
                {
                    throw ex;
                }

                var errorMessage = ex.Message;
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.InternalServerException);
            }

            return result;
        }

        public async Task<ApiResultModel<bool>> DeleteCategory_v2(int id)
        {
            var result = new ApiResultModel<bool>();

            try
            {
                var parameters = new List<SqlParameter>();

                SqlParameter param = new SqlParameter();
                param.ParameterName = "@categoryId";
                param.SqlDbType = SqlDbType.Int;
                param.Value = id;

                parameters.Add(param);

               _unitOfWork.ExecuteSp("sp_deleteCategory_by_id", parameters.ToArray());
                result = new ApiSuccessResultModel<bool>(true);
            }
            catch (Exception ex)
            {
                if (ExceptionHelper.IsCustomException(ex))
                {
                    throw ex;
                }

                var errorMessage = ex.Message;
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.InternalServerException);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategoriesWithEagerLoading()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll().Include(x => x.Productions).ToList();
            var categoriesDto = categories.Select(x => new CategoryDto
            {
                Id = x.Id,
                Name = x.Name,
                ProductName = x.Productions.Select(p => p.Name).ToList()
            }).ToList();

            var result = new ApiSuccessResultModel<List<CategoryDto>>(categoriesDto);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategoriesWithExpicitLoading()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll().ToList();
            foreach (var category in categories)
            {
                _dbContext.Entry(category).Collection(c => c.Productions).Load(); // loads Productions collection 

                //_dbContext.Entry(category).Collection(c => c.Productions)
                //                          .Query()
                //                                .Where(p => p.Name.StartsWith("t"))
                //                                .ToList();
                                                
            }

            var categoriesDto = categories.Select(x => new CategoryDto
            {
                Id = x.Id,
                Name = x.Name,
                ProductName = x.Productions.Select(p => p.Name).ToList()
            }).ToList();

            var result = new ApiSuccessResultModel<List<CategoryDto>>(categoriesDto);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories()
        {
            var result = new ApiResultModel<List<CategoryDto>>();

            try
            {
                var categories = _unitOfWork.CategoryRepository.FindAll();
                var products = _unitOfWork.ProductRepository.FindAll();

                //var test = categories.ToList();
                //foreach (var category in test)
                //{
                //    var productEntities = category.Productions ?? new List<Data.Entities.Product>();
                //    foreach(var productEntity in productEntities)
                //    {
                //        var productName = productEntity.Name;
                //    }
                //}

                //var myResultProjection = (from c in categories
                //                         join p in products
                //                         on c.Id equals p.CategoryId
                //                         select new CategoryDto
                //                         {
                //                             Id = c.Id,
                //                             Name = c.Name,
                //                             ProductName = c.Productions.Select(p => p.Name).ToList()
                //                         }).ToList();

                //result = new ApiSuccessResultModel<List<CategoryDto>>(myResultProjection);

                var myResult = (from c in categories
                               join p in products
                               on c.Id equals p.CategoryId
                               select new
                               {
                                   CategoryId = c.Id,
                                   CategoryName = c.Name,
                                   ProductName = p.Name
                               }).ToList();

                //var temp = myResult.Where(r => r.CategoryId == 6 || r.CategoryId == 4).ToList();
                //temp = temp.Where(r => r.ProductName.StartsWith("t")).ToList();

                //// Add more product
                //var product = new Data.Entities.Product
                //{
                //    Name = $"ttt_{DateTime.Now}",
                //    CategoryId = 4
                //};

                //_unitOfWork.ProductRepository.Add(product);
                //await _unitOfWork.Commit();


                var group = (from r in myResult
                             group r by r.CategoryId into g
                             let firstGroup = g.First()
                             select new CategoryDto
                             {
                                 Id = g.Key,
                                 Name = firstGroup.CategoryName,
                                 ProductName = g.Select(p => p.ProductName).ToList()
                             }).ToList();

                result = new ApiSuccessResultModel<List<CategoryDto>>(group);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<List<CategoryDto>>(ex.Message);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Left_Join()
        {
            var result = new ApiResultModel<List<CategoryDto>>();

            try
            {
                var categories = _unitOfWork.CategoryRepository.FindAll();
                var products = _unitOfWork.ProductRepository.FindAll();

                //var test = (from c in categories
                //            join p in products
                //            on c.Id equals p.CategoryId into temp
                //            from productResult in temp.DefaultIfEmpty()
                //            select new CategoryDto
                //            {
                //                Id = c.Id,
                //                Name = c.Name,
                //                ProductName = productResult == null ? new List<string>() : new List<string>() { productResult.Name }
                //            } into t                            
                //            group t by t.Id into g
                //            orderby g.Key
                //            let firstGroup = g.First()
                //            select new CategoryDto
                //            {
                //                Id = g.Key,
                //                Name = firstGroup.Name,
                //                ProductName = g.SelectMany(p => p.ProductName).ToList()
                //            }).ToList();


                var myResult = (from c in categories
                               join p in products
                               on c.Id equals p.CategoryId into temp
                               from productResult in temp.DefaultIfEmpty()
                               select new
                               {
                                   CategoryId = c.Id,
                                   CategoryName = c.Name,
                                   ProductName = productResult == null ? null : productResult.Name
                                }).AsEnumerable();

                var group = (from r in myResult
                             group r by r.CategoryId into g
                             orderby g.Key
                             let firstGroup = g.First()
                             select new CategoryDto
                             {
                                 Id = g.Key,
                                 Name = firstGroup.CategoryName,
                                 ProductName = g.Select(p => p.ProductName).ToList()
                             }).ToList();

                result = new ApiSuccessResultModel<List<CategoryDto>>(group);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<List<CategoryDto>>(ex.Message);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Inner_Join()
        {
            var result = new ApiResultModel<List<CategoryDto>>();

            try
            {
                var categories = _unitOfWork.CategoryRepository.FindAll();
                var products = _unitOfWork.ProductRepository.FindAll();

                var myResult = (from c in categories
                                join p in products
                                on c.Id equals p.CategoryId
                                select new
                                {
                                    CategoryId = c.Id,
                                    CategoryName = c.Name,
                                    ProductName = p.Name
                                }).AsEnumerable();

                var group = (from r in myResult
                             group r by r.CategoryId into g
                             orderby g.Key
                             let firstGroup = g.First()
                             select new CategoryDto
                             {
                                 Id = g.Key,
                                 Name = firstGroup.CategoryName,
                                 ProductName = g.Select(p => p.ProductName).ToList()
                             }).ToList();

                result = new ApiSuccessResultModel<List<CategoryDto>>(group);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<List<CategoryDto>>(ex.Message);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Navigation_Property()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll();

            var categoriesDto = (from c in categories                                              
                                 select new CategoryDto
                                 {
                                     Id = c.Id,
                                     Name = c.Name,
                                     ProductName = c.Productions.Select(p => p.Name).ToList()
                                 }).ToList();

            var result = new ApiSuccessResultModel<List<CategoryDto>>(categoriesDto);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_Lazy_Loading()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll().ToList();
            var categoriesDto = new List<CategoryDto>();
            

            foreach (var category in categories)
            {
                var productEntities = category.Productions ?? new List<Data.Entities.Product>();

                categoriesDto.Add(new CategoryDto
                {
                    Id = category.Id,
                    Name = category.Name,
                    ProductName = productEntities.Select(p => p.Name).ToList()
                });
            };

            var result = new ApiSuccessResultModel<List<CategoryDto>>(categoriesDto);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_IQueryable()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll();
            var products = _unitOfWork.ProductRepository.FindAll();

            var myResult = from c in categories
                           join p in products
                           on c.Id equals p.CategoryId
                           select new
                           {
                               CategoryId = c.Id,
                               CategoryName = c.Name,
                               ProductName = p.Name
                           };

            var temp = myResult.Where(r => r.CategoryId == 6 || r.CategoryId == 4);
            temp = temp.Where(r => r.ProductName.StartsWith("t"));

            // Add more product
            var product = new Data.Entities.Product
            {
                Name = $"ttt_{DateTime.Now}",
                CategoryId = 4
            };

            _unitOfWork.ProductRepository.Add(product);
            await _unitOfWork.Commit();

            var test = temp.ToList();

            var group = (from r in test
                         group r by r.CategoryId into g
                         let firstGroup = g.First()
                         select new CategoryDto
                         {
                             Id = g.Key,
                             Name = firstGroup.CategoryName,
                             ProductName = g.Select(p => p.ProductName).ToList()
                         }).ToList();

            var result = new ApiSuccessResultModel<List<CategoryDto>>(group);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_IEnumerable()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll();
            var products = _unitOfWork.ProductRepository.FindAll();

            var myResult = from c in categories
                           join p in products
                           on c.Id equals p.CategoryId
                           select new 
                           {
                               CategoryId = c.Id,
                               CategoryName = c.Name,
                               ProductName = p.Name
                           };

            var temp = myResult.Where(r => r.CategoryId == 6 || r.CategoryId == 4).AsEnumerable();
            temp = temp.Where(r => r.ProductName.StartsWith("t"));


            // Add more product
            var product = new Data.Entities.Product
            {
                Name = $"ttt_{DateTime.Now}",
                CategoryId = 4
            };

            _unitOfWork.ProductRepository.Add(product);
            await _unitOfWork.Commit();

            var test = temp.ToList();

            var group = (from r in test
                         group r by r.CategoryId into g
                         let firstGroup = g.First()
                         select new CategoryDto
                         {
                             Id = g.Key,
                             Name = firstGroup.CategoryName,
                             ProductName = g.Select(p => p.ProductName).ToList()
                         }).ToList();

            var result = new ApiSuccessResultModel<List<CategoryDto>>(group);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_With_ToList()
        {
            var categories = _unitOfWork.CategoryRepository.FindAll();
            var products = _unitOfWork.ProductRepository.FindAll();

            var myResult = from c in categories
                           join p in products
                           on c.Id equals p.CategoryId
                           select new
                           {
                               CategoryId = c.Id,
                               CategoryName = c.Name,
                               ProductName = p.Name
                           };

            var temp = myResult.Where(r => r.CategoryId == 6 || r.CategoryId == 4).ToList();
            temp = temp.Where(r => r.ProductName.StartsWith("t")).ToList();

            // Add more product
            var product = new Data.Entities.Product
            {
                Name = $"ttt_{DateTime.Now}",
                CategoryId = 4
            };

            _unitOfWork.ProductRepository.Add(product);
            await _unitOfWork.Commit();

            var test = temp.ToList();

            var group = (from r in test
                         group r by r.CategoryId into g
                         let firstGroup = g.First()
                         select new CategoryDto
                         {
                             Id = g.Key,
                             Name = firstGroup.CategoryName,
                             ProductName = g.Select(p => p.ProductName).ToList()
                         }).ToList();

            var result = new ApiSuccessResultModel<List<CategoryDto>>(group);

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_v2()
        {
            var result = new ApiResultModel<List<CategoryDto>>();

            try
            {
                var dataset = _unitOfWork.ExecuteSp("sp_getCategories");
                var dataTable = dataset.Tables[0];
                var categories = DataTableHelper.ConvertToList<CategoryDto>(dataTable);

                result = new ApiSuccessResultModel<List<CategoryDto>>(categories);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<List<CategoryDto>>(ex.Message);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_v3()
        {
            var result = new ApiResultModel<List<CategoryDto>>();

            try
            {
                var categoriesInMemoryCache = _memoryCache.Get<List<CategoryDto>>(CommonConstants.CategoryMemoryCache);

                if (categoriesInMemoryCache == null)
                {
                    categoriesInMemoryCache = _unitOfWork.CategoryRepository.FindAll()
                                                                .Select(c => new CategoryDto
                                                                {
                                                                    Id = c.Id,
                                                                    Name = c.Name,
                                                                   
                                                                }).ToList();

                    _memoryCache.Set(CommonConstants.CategoryMemoryCache, categoriesInMemoryCache);
                }

                result = new ApiSuccessResultModel<List<CategoryDto>>(categoriesInMemoryCache);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<List<CategoryDto>>(ex.Message);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<CategoryDto>>> GetCategories_v4()
        {
            var result = new ApiResultModel<List<CategoryDto>>();
            var categories = new List<CategoryDto>();

            try
            {
                var categoriesInRedisCache = await _redisCacheHelper.GetValue(CommonConstants.CategoryRedisCache);

                if (string.IsNullOrEmpty(categoriesInRedisCache))
                {
                    categories = _unitOfWork.CategoryRepository.FindAll()
                                                                .Select(c => new CategoryDto
                                                                {
                                                                    Id = c.Id,
                                                                    Name = c.Name
                                                                }).ToList();

                    await _redisCacheHelper.SetValue(JsonConvert.SerializeObject(categories), CommonConstants.CategoryRedisCache);
                }
                else
                {
                    categories = JsonConvert.DeserializeObject<List<CategoryDto>>(categoriesInRedisCache);
                }

                result = new ApiSuccessResultModel<List<CategoryDto>>(categories);
            }
            catch (Exception ex)
            {
                result = new ApiErrorResultModel<List<CategoryDto>>(ex.Message);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<CategoryDto>> GetCategoryById(int id)
        {
            var result = new ApiResultModel<CategoryDto>();

            //try
            {
                if (id <= 0)
                {
                    var errorMessage = $"Id: {id} is invalid";
                    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.BadRequestException);
                }

                var category = _unitOfWork.CategoryRepository.FindAll(c => c.Id == id)
                                                             .Select(c => new CategoryDto
                                                             {
                                                                 Id = c.Id,
                                                                 Name = c.Name
                                                             }).FirstOrDefault();

                if (category == null)
                {
                    var errorMessage = $"Id: {id} is not found";
                    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.NotFoundException);
                }

                result = new ApiSuccessResultModel<CategoryDto>(category);
            }
            //catch (Exception ex)
            //{
            //    if (ExceptionHelper.IsCustomException(ex))
            //    {
            //        throw ex;
            //    }

            //    var errorMessage = ex.Message;
            //    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.InternalServerException);
            //}

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<CategoryDto>> GetCategoryById_v2(int categoryId)
        {
            var result = new ApiResultModel<CategoryDto>();

            try
            {
                if (categoryId <= 0)
                {
                    var errorMessage = $"Id: {categoryId} is invalid";
                    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.BadRequestException);
                }

                var parameters = new List<SqlParameter>();

                SqlParameter param = new SqlParameter();
                param.ParameterName = "@categoryId";
                param.SqlDbType = SqlDbType.Int;
                param.Value = categoryId;
                param.Direction = ParameterDirection.Input;

                parameters.Add(param);

                var dataset = _unitOfWork.ExecuteSp("sp_getCategory_by_id", parameters.ToArray());
                var dataTable = dataset.Tables[0];
                var categories = DataTableHelper.ConvertToList<CategoryDto>(dataTable);
                var category = categories.FirstOrDefault();

                if (category == null)
                {
                    var errorMessage = $"Id: {categoryId} is not found";
                    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.NotFoundException);
                }

                result = new ApiSuccessResultModel<CategoryDto>(category);
            }
            catch (Exception ex)
            {
                if (ExceptionHelper.IsCustomException(ex))
                {
                    throw ex;
                }

                var errorMessage = ex.Message;
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.InternalServerException);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<CategoryDto>> GetCategoryById_v3(int categoryId)
        {
            var result = new ApiResultModel<CategoryDto>();

            try
            {
                if (categoryId <= 0)
                {
                    var errorMessage = $"Id: {categoryId} is invalid";
                    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.BadRequestException);
                }

                var parameters = new List<SqlParameter>();

                SqlParameter param = new SqlParameter();
                param.ParameterName = "@categoryId";
                param.SqlDbType = SqlDbType.Int;
                param.Value = categoryId;

                parameters.Add(param);

                var dataset = _unitOfWork.ExecuteSp("sp_getCategory_by_id", parameters.ToArray());
                var dataTable = dataset.Tables[0];
                var categories = DataTableHelper.ConvertToList<CategoryDto>(dataTable);
                var category = categories.FirstOrDefault();

                if (category == null)
                {
                    var errorMessage = $"Id: {categoryId} is not found";
                    BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.NotFoundException);
                }

                result = new ApiSuccessResultModel<CategoryDto>(category);
            }
            catch (Exception ex)
            {
                if (ExceptionHelper.IsCustomException(ex))
                {
                    throw ex;
                }

                var errorMessage = ex.Message;
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.InternalServerException);
            }

            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<CategoryDto>> GetCategoryById_v4(int id)
        {
            var result = new ApiResultModel<CategoryDto>();
            if (id <= 0)
            {
                var errorMessage = $"Id: {id} is invalid";
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.BadRequestException);
            }

            var test = _unitOfWork.CategoryRepository.FindAll(c => _dbContext.GetDiffDate(c.CreatedDate) == 3).ToList();
            
            var category = _dbContext.GetCategoryById(id).FirstOrDefault();

            if (category == null)
            {
                var errorMessage = $"Id: {id} is not found";
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.NotFoundException);
            }

            result = new ApiSuccessResultModel<CategoryDto>(category);

            return await Task.FromResult(result);
        }
    }
}
