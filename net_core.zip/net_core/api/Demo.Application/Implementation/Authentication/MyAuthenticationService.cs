﻿using Demo.Application.Interfaces.Authentication;
using Demo.Utilities.Constants;
using Demo.Utilities.Dtos;
using Demo.Utilities.Helpers;
using Demo.Utilities.Models.Common;
using Demo.Utilities.Models.Login;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.WebSockets;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using static Demo.Utilities.Enums.Enums;

namespace Demo.Application.Implementation.Authentication
{
    public class MyAuthenticationService : IMyAuthenticationService
    {
        private readonly IConfiguration _configuration;

        public MyAuthenticationService(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        public async Task<ApiResultModel<string>> Authenticate(LoginModel request)
        {
            var isValidUser = ClaimHelper.IsValidUser(request);
            if (!isValidUser)
            {
                return new ApiErrorResultModel<string>("Invalid Username or Password");
            }

            var claims = ClaimHelper.SetClaims(request.UserName);

            var token = CreateToken(claims);

            return await Task.FromResult(new ApiSuccessResultModel<string>(token));
        }

        private string CreateToken(List<Claim> claims)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtConfig_SecretKey"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var jwt = new JwtSecurityToken(_configuration["JwtConfig_Issuer"],
                                           _configuration["JwtConfig_Audience"],
                                            claims,
                                            expires: DateTime.Now.AddMinutes(15),
                                            signingCredentials: credentials
                                           );

            var token = new JwtSecurityTokenHandler().WriteToken(jwt);

            return token;
        }
    }
}
