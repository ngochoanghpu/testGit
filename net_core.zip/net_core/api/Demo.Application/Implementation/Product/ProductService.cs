﻿using AutoMapper;
using Demo.Application.Interfaces.Product;
using Demo.Data.EF;
using Demo.Infrastructure.UoW;
using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Dtos.Product;
using Demo.Utilities.Helpers;
using Demo.Utilities.Models.Common;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Demo.Utilities.Enums.Enums;

namespace Demo.Application.Implementation.Product
{
    public class ProductService : IProductService
    {
        private readonly IUnitOfWork _unitOfWork;

        private readonly IMapper _mapper;

        private readonly DemoContext _dbContext;

        public ProductService(IUnitOfWork unitOfWork, IMapper mapper, DemoContext dbContext)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _dbContext = dbContext;
        }

        public async Task<ApiResultModel<int>> AddProduct(ProductDto productDto)
        {
            var productEntity = _mapper.Map<ProductDto, Data.Entities.Product>(productDto);

            _unitOfWork.ProductRepository.Add(productEntity);
            await _unitOfWork.Commit();

            var productId = productEntity.Id;

            var result = new ApiSuccessResultModel<int>(productId);

            return result;
        }

        public async Task<ApiResultModel<List<ProductDto>>> GetProducts()
        {
            var productEntities = _unitOfWork.ProductRepository.FindAll().ToList();
            var productDtos = _mapper.Map<List<Data.Entities.Product>, List<ProductDto>>(productEntities);

            var result = new ApiSuccessResultModel<List<ProductDto>>(productDtos);
            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<ProductProjectDto>>> GetProductsByProjectTo()
        {
            var productEntities = _unitOfWork.ProductRepository.FindAll();
            var productDtos = await _mapper.ProjectTo<ProductProjectDto>(productEntities).ToListAsync();

            var result = new ApiSuccessResultModel<List<ProductProjectDto>>(productDtos);
            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<List<ProductDto>>> GetProductsWithRawSql()
        {
            var productEntities = _dbContext.Product.FromSqlRaw("Select * from Product").ToList();
            var productDtos = _mapper.Map<List<Data.Entities.Product>, List<ProductDto>>(productEntities);

            var result = new ApiSuccessResultModel<List<ProductDto>>(productDtos);
            return await Task.FromResult(result);
        }

        public async Task<ApiResultModel<ProductProjectDto>> GetProductById(int id)
        {
            if (id <= 0)
            {
                var errorMessage = $"Id: {id} is invalid";
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.BadRequestException);
            }

            var productEntity = _unitOfWork.ProductRepository.FindAll(c => c.Id == id);

            if (productEntity == null)
            {
                var errorMessage = $"Id: {id} is not found";
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.NotFoundException);
            }

            var productDto = await _mapper.ProjectTo<ProductProjectDto>(productEntity).FirstOrDefaultAsync();

            var result = new ApiSuccessResultModel<ProductProjectDto>(productDto);

            return result;
        }

        public async Task<ApiResultModel<ProductDto>> GetProductRawSqlById(int id)
        {
            if (id <= 0)
            {
                var errorMessage = $"Id: {id} is invalid";
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.BadRequestException);
            }

            var productEntity = _dbContext.Product.FromSqlRaw("SELECT * From Product Where id = {0}", id).FirstOrDefault();

            if (productEntity == null)
            {
                var errorMessage = $"Id: {id} is not found";
                BaseException<CategoryDto>.ThrowException(errorMessage, ExceptionType.NotFoundException);
            }

            var productDtos = _mapper.Map<Data.Entities.Product, ProductDto>(productEntity);

            var result = new ApiSuccessResultModel<ProductDto>(productDtos);

            return await Task.FromResult(result);
        }
    }
}
