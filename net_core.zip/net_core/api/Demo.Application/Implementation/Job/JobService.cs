﻿using Demo.Application.Interfaces.Job;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Application.Implementation.Job
{
    public class JobService : IJobService
    {
        private readonly ILogger<JobService> _logger;

        public JobService(ILogger<JobService> logger)
        {
            _logger = logger;
        }       

        public Task SendSms()
        {
            _logger.LogInformation($"Job {nameof(SendSms)} ran at: {DateTime.Now}");

            return Task.CompletedTask;
        }
    }
}
