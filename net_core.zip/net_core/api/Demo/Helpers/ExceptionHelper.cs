﻿using Demo.Utilities.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using static Demo.Utilities.Enums.Enums;

namespace Demo.Api.Helpers
{
    public class ExceptionHelper
    {
        public static ObjectResult GetObjectResult(Exception ex)
        {
            var responseData = Utilities.Helpers.ExceptionHelper.GetResponseData(ex);

            if (Utilities.Helpers.ExceptionHelper.IsBadRequestException(ex))
            {
                return new ObjectResult(responseData) { StatusCode = StatusCodes.Status400BadRequest };
            }

            if (Utilities.Helpers.ExceptionHelper.IsNotFoundException(ex))
            {
                return new ObjectResult(responseData) { StatusCode = StatusCodes.Status404NotFound };
            }

            return new ObjectResult(responseData) { StatusCode = StatusCodes.Status500InternalServerError };
        }
    }
}
