﻿using Demo.Application.Interfaces.Job;
using Hangfire;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Demo.Api.Extensions
{
    public static class ServiceProviderExtension
    {
        public static void ScheduleJob(this IServiceProvider serviceProvider, IConfiguration configuration)
        {
            JobSendSms(serviceProvider, configuration);
        }

        private static void JobSendSms(IServiceProvider serviceProvider, IConfiguration configuration)
        {
            var turnOnSendSms = Convert.ToBoolean(configuration["Hangfire_SendSMS_TurnOn"]);

            if (turnOnSendSms)
            {
                var scheduleSendSms = configuration["Hangfire_SendSMS_Schedule"];

                RecurringJob.AddOrUpdate(
                    "SendSMS",
                    () => serviceProvider.GetService<IJobService>().SendSms(),
                    scheduleSendSms);
            }
        }
    }
}
