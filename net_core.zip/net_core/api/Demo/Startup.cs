using Demo.Api.Authorization;
using Demo.Api.Extensions;
using Demo.Api.Filters;
using Demo.Api.Logger;
using Demo.Application.AutoMapper;
using Demo.Application.Implementation.Authentication;
using Demo.Application.Implementation.Category;
using Demo.Application.Implementation.Job;
using Demo.Application.Implementation.Product;
using Demo.Application.Interfaces.Authentication;
using Demo.Application.Interfaces.Category;
using Demo.Application.Interfaces.Job;
using Demo.Application.Interfaces.Product;
using Demo.Data.EF;
using Demo.Infrastructure.Repositories;
using Demo.Infrastructure.Repositories.Category;
using Demo.Infrastructure.Repositories.Product;
using Demo.Infrastructure.UoW;
using Demo.Utilities.Helpers.Cache.RedisCache;
using Hangfire;
using Hangfire.Logging;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using StackExchange.Redis;
using System;

namespace Demo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            AddDbContext(services);

            RegisterDI(services);

            AddSwagger(services);

            AddRouting(services);

            AddApiVersioning(services);

            AddRedisAsync(services);

            AddHangfire(services);

            AddBasicAuthentication(services);

            services.AddMvc(options =>
            {
                options.RespectBrowserAcceptHeader = true;
                options.OutputFormatters.Add(new XmlSerializerOutputFormatter());
            });

            // AutoMapper
            services.AddSingleton(AutoMapperConfig.RegisterMappings().CreateMapper());

            services.AddControllers(options => {
                options.Filters.Add(typeof(CustomExceptionFilter));
            });

            // Logger
            LogProvider.SetCurrentLogProvider(new NoLoggingProvider());
        }

        private void AddBasicAuthentication(IServiceCollection services)
        {
            services.AddAuthentication("BasicAuthentication").AddScheme<AuthenticationSchemeOptions, DemoAuthenticationHandler>("BasicAuthentication", null);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory, IServiceProvider serviceProvider)
        {
            //loggerFactory.AddFile(Configuration.GetSection("Logging"));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(c => 
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Demo API v1");
                c.SwaggerEndpoint("/swagger/v2/swagger.json", "Demo API v2");
                c.SwaggerEndpoint("/swagger/v3/swagger.json", "Demo API v3");
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            serviceProvider.ScheduleJob(Configuration);
        }

        private static void RegisterDI(IServiceCollection services)
        {
            services.AddTransient<DbInitializer>();
            services.AddTransient(typeof(IUnitOfWork), typeof(EFUnitOfWork));
            services.AddTransient(typeof(IRepository<,>), typeof(EFRepository<,>));
            services.AddTransient<ICategoryRepository, CategoryRepository>();
            services.AddTransient<IProductRepository, ProductRepository>();
            services.AddTransient<ICategoryService, CategoryService>();
            services.AddTransient<IProductService, ProductService>();
            services.AddTransient<IMyAuthenticationService, MyAuthenticationService>();
            services.AddTransient<IRedisCacheHelper, RedisCacheHelper>();
            services.AddTransient<IJobService, JobService>();
        }

        private void AddDbContext(IServiceCollection services)
        {
            var connectionString = Configuration["ConnectionStrings:DefaultConnection"];

            services.AddDbContext<DemoContext>(options =>
            {
                options.UseSqlServer(connectionString, x => x.MigrationsAssembly("Demo.Data.EF"));
            });
        }

        private void AddApiVersioning(IServiceCollection services)
        {
            services.AddApiVersioning(option =>
            {
                option.ReportApiVersions = true;
            });

            services.AddVersionedApiExplorer(option =>
            {
                option.GroupNameFormat = "'v'VVV";
                option.SubstituteApiVersionInUrl = true;
            });
        }

        private static void AddSwagger(IServiceCollection services)
        {
            // Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Demo API", Version = "v1" });
                c.SwaggerDoc("v2", new OpenApiInfo { Title = "Demo API", Version = "v2" });
                c.SwaggerDoc("v3", new OpenApiInfo { Title = "Demo API", Version = "v3" });
                c.EnableAnnotations();

                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "Access Token Authorization header using the Bearer scheme (Example: 'Bearer 12345abcdef')",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        Array.Empty<string>()
                    }
                });
            });
        }

        private static void AddRouting(IServiceCollection services)
        {
            services.AddRouting(options => options.LowercaseUrls = true);
        }
        private void AddRedisAsync(IServiceCollection services)
        {
            var redisConnectionString = $"{Configuration["Redis:Host"]}:{Configuration["Redis:Port"]}";
            var options = ConfigurationOptions.Parse(redisConnectionString);

            ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(options);
            services.AddScoped(s => redis.GetDatabase());
        }

        private void AddHangfire(IServiceCollection services)
        {
            var connectionString = Configuration["ConnectionStrings:DefaultConnection"];

            services.AddHangfire(configuration => { configuration.UseSqlServerStorage(connectionString); });

            services.AddHangfireServer();
        }
    }
}
