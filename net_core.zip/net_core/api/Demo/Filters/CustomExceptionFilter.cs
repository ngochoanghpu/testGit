﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;
using System;

namespace Demo.Api.Filters
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            var result = Helpers.ExceptionHelper.GetObjectResult(context.Exception);

            // Set the result
            context.Result = result;
        }
    }
}
