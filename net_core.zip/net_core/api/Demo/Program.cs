using Demo.Data.EF;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog.Events;
using Serilog.Filters;
using Serilog.Formatting.Json;
using Serilog;
using System;
using System.Threading.Tasks;

namespace Demo
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            InitLogger(args);

            var host = CreateHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;

                try
                {
                    using (var context = new DemoContext(services.GetRequiredService<DbContextOptions<DemoContext>>()))
                    {
                        await context.Database.MigrateAsync(); //command: update-databas

                        var dbInitializer = services.GetService<DbInitializer>();
                        dbInitializer.Seed().Wait();
                    }
                }
                catch (Exception ex)
                {
                    var logger = services.GetService<ILogger<Program>>();
                    logger.LogError(ex, ex.Message);
                }
            }

            host.Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
               .UseSerilog();

        private static void InitLogger(string[] args)
        {
            var loggerConfiguration = new LoggerConfiguration();

            FilterLogger(loggerConfiguration);

            WriteLogToProvider(args, loggerConfiguration);
        }

        private static void FilterLogger(LoggerConfiguration loggerConfiguration)
        {
            loggerConfiguration.MinimumLevel.Information()
                               .Filter.ByExcluding(Matching.FromSource("Hangfire"))
                               .Filter.ByExcluding(Matching.FromSource("Microsoft.EntityFrameworkCore.Model.Validation"))
                               .Filter.ByExcluding(Matching.FromSource("Microsoft.AspNetCore.HttpsPolicy.HttpsRedirectionMiddleware"))
                               .Filter.ByExcluding(Matching.FromSource("Microsoft.AspNetCore.DataProtection.KeyManagement.XmlKeyManager"))
                               .Filter.ByExcluding(Matching.FromSource("Microsoft.AspNetCore.DataProtection.Repositories.FileSystemXmlRepository"))
                               .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                               .MinimumLevel.Override("Microsoft.Hosting.Lifetime", LogEventLevel.Warning);
        }

        private static void WriteLogToProvider(string[] args, LoggerConfiguration loggerConfiguration)
        {
            var configuration = GetConfiguration(args);

            if (IsWriteToConsole(configuration))
            {
                loggerConfiguration.WriteTo.Console(new JsonFormatter());
            }
            else if (IsWriteToFile(configuration))
            {
                // Add a log file that will be replaced by a new log file each day
                var pathFormat = configuration.GetSection("Logging:PathFormat").Value;
                loggerConfiguration.WriteTo.File(pathFormat, rollingInterval: RollingInterval.Day);
            }
            else
            {
                loggerConfiguration.WriteTo.Debug();
            }

            Log.Logger = loggerConfiguration.CreateLogger();
        }

        private static IConfigurationRoot GetConfiguration(string[] args)
        {
            var configuration = new ConfigurationBuilder()
                                    .AddEnvironmentVariables()
                                    .AddCommandLine(args)
                                    .AddJsonFile(GetAppSettingsEnvironment())
                                    .Build();

            return configuration;
        }

        private static string GetAppSettingsEnvironment()
        {
            var currentEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            return $"appsettings.{currentEnvironment}.json";
        }

        private static bool IsWriteToConsole(IConfigurationRoot configuration)
        {
            bool isWriteToConsole = configuration.GetSection("Logging:IsWriteToConsole")?.Value == bool.TrueString;

            return isWriteToConsole;
        }

        private static bool IsWriteToFile(IConfigurationRoot configuration)
        {
            bool isWriteToFile = configuration.GetSection("Logging:IsWriteToFile")?.Value == bool.TrueString;

            return isWriteToFile;
        }
    }
}
