﻿using Demo.Application.Interfaces.Category;
using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Exceptions;
using Demo.Utilities.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Demo.Api.Controllers.v3
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("3.0")]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        //[Produces("application/xml")]
        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories")]
        public async Task<IActionResult> GetCategories(string v3)
        {
            var categories = await _categoryService.GetCategories();

            return new ObjectResult(categories) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpGet]
        [Route("name")]
        [SwaggerOperation(Summary = "Get categories by name")]
        public async Task<IActionResult> GetCategoriesByName()
        {
            var categories = await _categoryService.GetCategories();

            return new ObjectResult(categories) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpGet]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Get category by id")]
        public async Task<IActionResult> GetCategoryById([Required] int id)
        {
            try
            {
                var category = await _categoryService.GetCategoryById(id);

                return new ObjectResult(category) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Add category")]
        public async Task<IActionResult> AddCategory(CategoryDto category)
        {
            var categoryId = await _categoryService.AddCategory(category);

            return new ObjectResult(categoryId) { StatusCode = StatusCodes.Status201Created };
        }

        [HttpPut]
        [SwaggerOperation(Summary = "Update category")]
        public async Task<IActionResult> UpdateCategory(CategoryDto category)
        {
            try
            {
                var result = await _categoryService.UpdateCategory(category);

                return new ObjectResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (BadRequestException ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
            catch (NotFoundException ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpDelete]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Delete category")]
        public async Task<IActionResult> DeleteCategory([Required] int id)
        {
            var result = await _categoryService.DeleteCategory(id);

            return new ObjectResult(result) { StatusCode = StatusCodes.Status204NoContent };
        }

    }
}
