﻿using Demo.Application.Interfaces.Category;
using Demo.Utilities.Dtos.Category;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Threading.Tasks;

namespace Demo.Api.Controllers
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    public class TransactionController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        public TransactionController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Using Transaction Scope")]
        [Route("transaction-scope")]
        public async Task<IActionResult> UsingTransaction()
        {
            var result = await _categoryService.UsingTransactionScope();

            return Ok(result);
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Using Transaction Isolation Level")]
        [Route("transaction-isolation-level")]
        public async Task<IActionResult> UsingTransactionIsolationLevel()
        {
            var result = await _categoryService.UsingTransactionIsolationLevel();

            return Ok(result);
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Using Transaction Isolation Level ReadUncommited")]
        [Route("transaction-isolation-level-read-uncommited")]
        public async Task<IActionResult> UsingTransactionReadUncomited()
        {
            var result = await _categoryService.UsingTransactionReadUncommited();

            return Ok(result);
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Using Transaction Isolation Level ReadCommited")]
        [Route("transaction-isolation-level-read-commited")]
        public async Task<IActionResult> UsingTransactionReadCommited()
        {
            var result = await _categoryService.UsingTransactionReadCommited();

            return Ok(result);
        }

        [HttpPost]
        [SwaggerOperation(Summary = "add category without transaction")]
        [Route("without-transaction")]
        public async Task<IActionResult> AddCategoryWithoutTransaction(CategoryDto category)
        {
            var categoryId = await _categoryService.AddCategoryWithoutTransaction(category);

            return new ObjectResult(categoryId) { StatusCode = StatusCodes.Status201Created };
        }

        [HttpPost]
        [SwaggerOperation(Summary = "add category with transaction by only SaveChange")]
        [Route("with-transaction-by-only-SaveChange")]
        public async Task<IActionResult> AddCategory(CategoryDto category)
        {
            var categoryId = await _categoryService.AddCategory(category);

            return new ObjectResult(categoryId) { StatusCode = StatusCodes.Status201Created };
        }
    }
}
