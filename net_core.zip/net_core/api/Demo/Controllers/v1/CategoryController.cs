﻿using Demo.Api.Authorization;
using Demo.Application.Interfaces.Category;
using Demo.Utilities.Constants;
using Demo.Utilities.Dtos.Category;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Demo.Api.Controllers.v1
{
    //api/Category/
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        private readonly IMemoryCache _memoryCache;

        private readonly ILogger<CategoryController> _logger;

        public CategoryController(ICategoryService categoryService, IMemoryCache memoryCache, ILogger<CategoryController> logger)
        {
            _categoryService = categoryService;
            _memoryCache = memoryCache;
            _logger = logger;
        }
        
        [HttpGet]
        //[DemoAuthorize(RoleConstants.AdminRole)]
        [SwaggerOperation(Summary = "Get all categories v1 with basic authentication")]
        public async Task<IActionResult> GetCategories_v1()
        {
            try
            {
                _logger.LogInformation("Get all categories");

                var categories = await _categoryService.GetCategories();

                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Ocurred error {nameof(GetCategories_v1)}: {ex.Message}");
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with left join")]
        [Route("left-join")]
        public async Task<IActionResult> GetCategories_With_Left_Join()
        {
            var categories = await _categoryService.GetCategories_With_Left_Join();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with inner join")]
        [Route("inner-join")]
        public async Task<IActionResult> GetCategories_With_Inner_Join()
        {
            var categories = await _categoryService.GetCategories_With_Inner_Join();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with navigation property")]
        [Route("navigation-property")]
        public async Task<IActionResult> GetCategories_With_Navigation_Property()
        {
            var categories = await _categoryService.GetCategories_With_Navigation_Property();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with IQueryable")]
        [Route("IQueryable")]
        public async Task<IActionResult> GetCategories_With_IQueryable()
        {
            var categories = await _categoryService.GetCategories_With_IQueryable();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with IEnumerable")]
        [Route("IEnumerable")]
        public async Task<IActionResult> GetCategories_With_IEnumerable()
        {
            var categories = await _categoryService.GetCategories_With_IEnumerable();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with ToList")]
        [Route("ToList")]
        public async Task<IActionResult> GetCategories_With_ToList()
        {
            var categories = await _categoryService.GetCategories_With_ToList();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with Lazy Loading")]
        [Route("lazy-loading")]
        public async Task<IActionResult> GetCategories_With_Lazy_Loading()
        {
            var categories = await _categoryService.GetCategories_With_Lazy_Loading();

            return Ok(categories);
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with eager loading")]
        [Route("eager-loading")]
        public async Task<IActionResult> GetCategories_With_EagerLoading()
        {
            try
            {
                _logger.LogInformation("Get all categories");

                var categories = await _categoryService.GetCategoriesWithEagerLoading();

                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Ocurred error {nameof(GetCategories_v1)}: {ex.Message}");
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories with expicit loading")]
        [Route("expicit-loading")]
        public async Task<IActionResult> GetCategories_With_ExpicitLoading()
        {
            try
            {
                _logger.LogInformation("Get all categories");

                var categories = await _categoryService.GetCategoriesWithExpicitLoading();

                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Ocurred error {nameof(GetCategories_v1)}: {ex.Message}");
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [DemoAuthorize(RoleConstants.AdminRole)]
        [SwaggerOperation(Summary = "Get all categories v2 with bearer token")]
        [Route("all-category-v2")]
        public async Task<IActionResult> GetCategories_v2()
        {
            try
            {
                var categories = await _categoryService.GetCategories_v2();

                return Ok(categories);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories by Mem-Cache")]
        [Route("get-category-by-memory-cache")]
        public async Task<IActionResult> GetCategories_v3()
        {
            try
            {
                var categories = await _categoryService.GetCategories_v3();

                return Ok(categories);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories by-Redis-Cache")]
        [Route("get-category-by-reids-cache")]
        public async Task<IActionResult> GetCategories_v4()
        {
            try
            {
                var categories = await _categoryService.GetCategories_v4();

                return Ok(categories);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Get category by id")]
        public async Task<IActionResult> GetCategoryById([Required] int id)
        {
            var category = await _categoryService.GetCategoryById(id);
            return new ObjectResult(category) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpGet]
        [Route("get-by-SP/{id}")]
        [SwaggerOperation(Summary = "Get category by id by Store Procedure")]
        public async Task<IActionResult> GetCategoryById_SP([Required] int id)
        {
            var category = await _categoryService.GetCategoryById_v2(id);
            return new ObjectResult(category) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpGet]
        [Route("get-by-Func/{id}")]
        [SwaggerOperation(Summary = "Get category by id by Function")]
        public async Task<IActionResult> GetCategoryById_Func([Required] int id)
        {
            var category = await _categoryService.GetCategoryById_v4(id);
            return new ObjectResult(category) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Add category")]
        public async Task<IActionResult> AddCategory(CategoryDto category)
        {
            try
            {
                var categoryId = await _categoryService.AddCategory(category);

                return new ObjectResult(categoryId) { StatusCode = StatusCodes.Status201Created };
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Add category by Store Procedure")]
        [Route("add-cateogry-by-SP")]
        public async Task<IActionResult> AddCategory_v2(CategoryDto category)
        {
            try
            {
                var categoryId = await _categoryService.AddCategory_v2(category);

                return new ObjectResult(categoryId) { StatusCode = StatusCodes.Status201Created };
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpPut]
        [SwaggerOperation(Summary = "Update category")]
        public async Task<IActionResult> UpdateCategory(CategoryDto category)
        {
            try
            {
                var result = await _categoryService.UpdateCategory(category);

                return new ObjectResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpPut]
        [SwaggerOperation(Summary = "Update category by Store Procedure")]
        [Route("update-category-by-SP")]
        public async Task<IActionResult> UpdateCategory_v2(CategoryDto category)
        {
            try
            {
                var result = await _categoryService.UpdateCategory_v2(category);

                return new ObjectResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpDelete]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Delete category")]
        public async Task<IActionResult> DeleteCategory([Required] int id)
        {
            try
            {
                var result = await _categoryService.DeleteCategory(id);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpDelete]
        [Route("delete-category/{id}")]
        [SwaggerOperation(Summary = "Delete category by Store Procedure")]
        public async Task<IActionResult> DeleteCategory_v2([Required] int id)
        {
            try
            {
                var result = await _categoryService.DeleteCategory_v2(id);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpGet]
        [Route("get-by-id/{categoryId}")]
        [SwaggerOperation(Summary = "Get category by id by Store Procedure")]
        public async Task<IActionResult> GetCategoryById_v2([Required] int categoryId)
        {
            var category = await _categoryService.GetCategoryById_v2(categoryId);
            return new ObjectResult(category) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpPut]
        [Route("clear-caching")]
        [SwaggerOperation(Summary = "Clear memory caching")]
        public IActionResult ClearCaching(string key)
        {
            try
            {
                _memoryCache.Remove(key);

                return Ok();
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }
    }
}
