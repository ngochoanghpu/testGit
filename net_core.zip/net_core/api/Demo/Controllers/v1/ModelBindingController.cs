﻿using Demo.Utilities.Dtos.ModelBinding;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using static Demo.Utilities.Enums.Enums;

namespace Demo.Api.Controllers.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    public class ModelBindingController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Test(int age, string name, ExceptionType type)
        {
            return await Task.Run(() => Ok());
        }

        [HttpGet]
        [Route("test-from-query")]
        public async Task<IActionResult> Test7([FromQuery] int age, string name, ExceptionType type)
        {
            return await Task.Run(() => Ok());
        }

        [HttpGet]
        [Route("get-list-id-from-query")]
        //https://localhost:44345/api/v1/modelbinding/get-list-id-from-query?ids=1&ids=2&ids=3&ids=0
        public async Task<IActionResult> GetListIds([FromQuery] List<int> ids)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPut]
        [Route("update-list-id")]
        public async Task<IActionResult> UpdateListIds(List<int> ids)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPut]
        [Route("update-list-id-by-from-header")]
        public async Task<IActionResult> UpdateListIdsByFromHeader([FromHeader] List<int> ids)
        {
            return await Task.Run(() => Ok());
        }

        [HttpDelete]
        [Route("Delete-list-id-by-from-query")]
        public async Task<IActionResult> DeleteListIdsByFromQuery([FromQuery] List<int> ids)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPost]
        //https://localhost:44345/api/v1/modelbinding?age=1&name=hoang&address=hcm
        public async Task<IActionResult> Test3([FromQuery] StudentDto studentDto)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPost]
        [Route("testing-from-body-2")]
        public async Task<IActionResult> Test4([FromBody] StudentDto studentDto, string phone)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPost]
        [Route("testing-from-body")]
        public async Task<IActionResult> TestFromBody([FromBody] StudentDto studentDto) //complex/primitive
        {
            return await Task.Run(() => Ok());
        }


        [HttpPost]
        [Route("testing-from-query-body")]
        public async Task<IActionResult> Test5([FromBody] int age, string name, string address)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPost]
        [Route("testing-from-query-body-header")]
        public async Task<IActionResult> Test567([FromBody] int age222, [FromHeader] string name, string address)
        {
            return await Task.Run(() => Ok());
        }

        [HttpPost]
        [Route("testing-from-form")]
        public async Task<IActionResult> Test567([FromForm] StudentDto studentDto)
        {
            return await Task.Run(() => Ok());
        }

        [HttpGet]
        [Route("testing-from-route/{studentId}")]
        public async Task<IActionResult> FromRoute([FromRoute] int studentId, string name, string address)
        {
            return await Task.Run(() => Ok());
        }
    }
}
