﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Threading.Tasks;
using System;
using Demo.Utilities.Models.Login;
using Demo.Application.Interfaces.Authentication;
using Demo.Application.Interfaces.Category;
using Microsoft.AspNetCore.Authorization;

namespace Demo.Api.Controllers.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    public class AuthenticationController : ControllerBase
    {
        private readonly IMyAuthenticationService _authenticationService;

        public AuthenticationController(IMyAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

       
        [HttpPost]
        [Route("authenticate")]
        [SwaggerOperation(Summary = "Authenticate user")]
        public async Task<IActionResult> Authenticate(LoginModel request)
        {
            try
            {
                var token = await _authenticationService.Authenticate(request);

                return new ObjectResult(token) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }
    }
}
