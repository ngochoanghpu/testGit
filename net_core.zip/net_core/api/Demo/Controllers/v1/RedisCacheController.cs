﻿using Demo.Utilities.Helpers.Cache.RedisCache;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Demo.Api.Controllers.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    public class RedisCacheController : ControllerBase
    {
        private readonly IRedisCacheHelper _redisCacheHelper;

        public RedisCacheController(IRedisCacheHelper redisCacheHelper)
        {
            _redisCacheHelper = redisCacheHelper;
        }

        [HttpPost]
        [Route("set-value")]
        public async Task<IActionResult> SetValue(string value, string key)
        {
            var result = await _redisCacheHelper.SetValue(value, key);

            return Ok(result);
        }

        [HttpGet]
        [Route("get-value")]
        public async Task<IActionResult> GetValue(string key)
        {
            var result = await _redisCacheHelper.GetValue(key);

            return Ok(result);
        }

        [HttpGet]
        [Route("exist-key")]
        public async Task<IActionResult> IsExistKey(string key)
        {
            var result = await _redisCacheHelper.IsExistKey(key);

            return Ok(result);
        }

        [HttpPut]
        [Route("delete-key")]
        public async Task<IActionResult> DeleteKey(string key)
        {
            var result = await _redisCacheHelper.DeleteKey(key);

            return Ok(result);
        }
    }
}
