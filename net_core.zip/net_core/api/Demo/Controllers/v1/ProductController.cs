﻿using Demo.Utilities.Dtos.Category;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Threading.Tasks;
using System;
using Demo.Utilities.Dtos.Product;
using Demo.Application.Interfaces.Category;
using Demo.Application.Interfaces.Product;
using Demo.Application.Implementation.Category;
using Microsoft.AspNetCore.Authorization;
using System.ComponentModel.DataAnnotations;

namespace Demo.Api.Controllers.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1.0")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Add product")]
        public async Task<IActionResult> AddProduct(ProductDto productDto)
        {
            var productId = await _productService.AddProduct(productDto);

            return new ObjectResult(productId) { StatusCode = StatusCodes.Status201Created };
        }

        [HttpGet]
        [SwaggerOperation(Summary = "Get all product")]
        public async Task<IActionResult> GetProducts()
        {
            var categories = await _productService.GetProducts();

            return Ok(categories);
        }

        [HttpGet]
        [Route("get-all-category-using-project")]
        [SwaggerOperation(Summary = "Get all product using ProjectTo")]
        public async Task<IActionResult> GetProductsWithProjectTo()
        {
            var categories = await _productService.GetProductsByProjectTo();

            return Ok(categories);
        }

        [HttpGet]
        [Route("get-all-category-using-raw-sql")]
        [SwaggerOperation(Summary = "Get all product using Raw Sql")]
        public async Task<IActionResult> GetProductsWithRawSql()
        {
            var categories = await _productService.GetProductsWithRawSql();

            return Ok(categories);
        }

        [HttpGet]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Get product by id")]
        public async Task<IActionResult> GetCategoryById([Required] int id)
        {
            var product = await _productService.GetProductById(id);
            return Ok(product);
        }

        [HttpGet]
        [Route("{id}/get-product-with-raw-sql-by-id")]
        [SwaggerOperation(Summary = "Get product by id by raw sql")]
        public async Task<IActionResult> GetCategoryRawSqlById([Required] int id)
        {
            var product = await _productService.GetProductRawSqlById(id);
            return Ok(product);
        }
    }
}
