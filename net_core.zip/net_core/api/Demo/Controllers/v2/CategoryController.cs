﻿using Demo.Application.Interfaces.Category;
using Demo.Utilities.Dtos.Category;
using Demo.Utilities.Exceptions;
using Demo.Utilities.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Demo.Api.Controllers.v2
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("2.0")]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryService _categoryService;

        private readonly ILogger<CategoryController> _logger;

        public CategoryController(ICategoryService categoryService, ILogger<CategoryController> logger)
        {
            _categoryService = categoryService;
            _logger = logger;
        }

        //[Produces("application/xml")]
        [HttpGet]
        [SwaggerOperation(Summary = "Get all categories")]
        public async Task<IActionResult> GetCategories(string v2)
        {
            _logger.LogError("Get all categories");

            var categories = await _categoryService.GetCategories();

            return new ObjectResult(categories) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpGet]
        [Route("name")]
        [SwaggerOperation(Summary = "Get categories by name")]
        public async Task<IActionResult> GetCategoriesByName()
        {
            var categories = await _categoryService.GetCategories();

            return new ObjectResult(categories) { StatusCode = StatusCodes.Status200OK };
        }

        [HttpGet]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Get category by id")]
        public async Task<IActionResult> GetCategoryById([Required] int id)
        {
            object responseData;

            try
            {
                var category = await _categoryService.GetCategoryById(id);
                
                 return new ObjectResult(category) { StatusCode = StatusCodes.Status200OK };
                
            }
            catch(BadRequestException ex)
            {
                responseData = ExceptionHelper.GetResponseData(ex);
                return new ObjectResult(responseData) { StatusCode = StatusCodes.Status400BadRequest };
            }
            catch (NotFoundException ex)
            {
                responseData = ExceptionHelper.GetResponseData(ex);
                return new ObjectResult(responseData) { StatusCode = StatusCodes.Status404NotFound };
            }
            catch (Exception ex)
            {
                responseData = ExceptionHelper.GetResponseData(ex);
                return new ObjectResult(responseData) { StatusCode = StatusCodes.Status500InternalServerError };
            }
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Add category")]
        public async Task<IActionResult> AddCategory(CategoryDto category)
        {
            var categoryId = await _categoryService.AddCategory(category);

            return new ObjectResult(categoryId) { StatusCode = StatusCodes.Status201Created };
        }

        [HttpPut]
        [SwaggerOperation(Summary = "Update category")]
        public async Task<IActionResult> UpdateCategory(CategoryDto category)
        {
            try
            {
                var result = await _categoryService.UpdateCategory(category);

                return new ObjectResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (BadRequestException ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
            catch (NotFoundException ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
            catch (Exception ex)
            {
                return Helpers.ExceptionHelper.GetObjectResult(ex);
            }
        }

        [HttpDelete]
        [Route("{id}")]
        [SwaggerOperation(Summary = "Delete category")]
        public async Task<IActionResult> DeleteCategory([Required] int id)
        {
            var result = await _categoryService.DeleteCategory(id);

            return new ObjectResult(result) { StatusCode = StatusCodes.Status204NoContent };
        }

    }
}
