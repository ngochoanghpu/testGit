﻿using Demo.Api.Extensions;
using Demo.Utilities.Constants;
using Demo.Utilities.Helpers;
using Hangfire.States;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace Demo.Api.Authorization
{
    public class DemoAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private readonly IConfiguration _configuration;

        public DemoAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options,
                                         ILoggerFactory logger,
                                         UrlEncoder encoder,
                                         ISystemClock clock,
                                         IConfiguration configuration
                                         ) : base(options, logger, encoder, clock)
        {
            _configuration = configuration;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var hasAuthHeader = Request.Headers.TryGetValue(CommonConstants.Authorization, out var authHeaders);

            if (!hasAuthHeader || authHeaders.Count < 1)
            {
                return AuthenticateResult.Fail("Token is invalid or it is not represented in request headers.");
            }

            var (scheme, token) = ParseAuthHeader(authHeaders[0]);

            if (!CommonConstants.BearerSchema.Equals(scheme, StringComparison.InvariantCultureIgnoreCase) &&
                !CommonConstants.BasicSchema.Equals(scheme, StringComparison.InvariantCultureIgnoreCase)
               )
            {
                return AuthenticateResult.Fail("Invalid authentication scheme.");
            }

            if (scheme == CommonConstants.BasicSchema)
            {
                return await HandleAuthenticateBasicSchemaAsync();
            }
            else
            {
                return await HandleAuthenticateBearerSchemaAsync(token);
            }
        }

        private static (string Scheme, string Token) ParseAuthHeader(string authHeader) //Tuple
        {
            string scheme = null;
            string token = null;

            if (string.IsNullOrEmpty(authHeader))
            {
                return (scheme, token);
            }

            var parts = authHeader.Split(' ');
            scheme = parts[0];

            if (parts.Length > 1)
            {
                token = parts[1];
            }

            return (scheme, token);
        }

        private async Task<AuthenticateResult> HandleAuthenticateBasicSchemaAsync()
        {
            string username;
            string password;
            try
            {
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers[CommonConstants.Authorization]);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                username = credentials[0];
                password = credentials[1];
            }
            catch
            {
                return AuthenticateResult.Fail("Invalid Authorization Header");
            }

            if (username != CommonConstants.Admin || password != "123456")
            {
                return AuthenticateResult.Fail("Invalid Username or Password");
            }

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, "basic"),
            };

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return await Task.Run(() => AuthenticateResult.Success(ticket));
        }

        private async Task<AuthenticateResult> HandleAuthenticateBearerSchemaAsync(string token)
        {
            try
            {
                var secretKey = _configuration["JwtConfig_SecretKey"];
                ClaimsPrincipal claimsPrincipal = DecodeJWTToken(token, secretKey);

                if (claimsPrincipal == null)
                {
                    return AuthenticateResult.Fail("Invalid token");
                }

                var identity = new ClaimsIdentity(claimsPrincipal.Claims, Scheme.Name);
                var principal = new ClaimsPrincipal(identity);
                var ticket = new AuthenticationTicket(principal, Scheme.Name);

                return await Task.Run(() => AuthenticateResult.Success(ticket));
            }
            catch
            {
                return AuthenticateResult.Fail("Invalid token");
            }
        }

        public static ClaimsPrincipal DecodeJWTToken(string token, string secretAuthKey)
        {
            var key = Encoding.ASCII.GetBytes(secretAuthKey);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = false,
                ValidateAudience = false
            };
            var claims = handler.ValidateToken(token, validations, out var tokenSecure);
            return claims;
        }
    }
}
