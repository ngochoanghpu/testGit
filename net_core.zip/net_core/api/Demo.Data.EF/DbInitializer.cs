﻿using Demo.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Data.EF
{
    public class DbInitializer
    {
        private readonly DemoContext _context;

        public DbInitializer(DemoContext context)
        {
            _context = context;
        }

        public async Task Seed()
        {
            await MigrateCategory();
        }

        private async Task MigrateCategory()
        {
            if (!_context.Category.Any())
            {
                _context.Category.AddRange(new List<Category>()
                {
                    new Category() {
                        Name = "Iphone",
                        Productions = new List<Product>
                        {
                            new Product
                            {
                                Name = "Iphone 6",
                                Code = "I",
                                Description = "This is iphone 6",
                                Price = 6000000
                            },
                            new Product
                            {
                                Name = "Iphone 12",
                                Code = "I",
                                Description = "This is iphone 12",
                                Price = 20000000
                            }
                        },
                        CreatedBy = "hoang.nguyenn"
                    },
                    new Category() {
                        Name = "Laptop",
                        Productions = new List<Product>
                        {
                            new Product
                            {
                                Name = "ThinkPad Lenovo",
                                Code = "L",
                                Description = "ThinkPad Lenovo Laptop",
                                Price = 16000000
                            }
                        },
                        CreatedBy = "hoang.nguyenn"
                    },
                });

                await _context.SaveChangesAsync();
            }
        }
    }
}
