﻿using Demo.Data.Entities;
using Demo.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using Demo.Utilities.Models.Common;
using Demo.Utilities.Dtos.Category;
using Microsoft.Extensions.Logging;

namespace Demo.Data.EF
{
    public class DemoContext : DbContext
    {
        public DemoContext(DbContextOptions<DemoContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // config function
            //modelBuilder.HasDbFunction(typeof(DemoContext)
            //       .GetMethod(nameof(GetCategoryById),
            //                  new[] { typeof(int) }))
            //       .HasName("fc_getCategory_by_id");

            //modelBuilder.HasDbFunction(typeof(DemoContext)
            //       .GetMethod(nameof(GetDiffDate),
            //                  new[] { typeof(DateTime) }))
            //       .HasName("fc_diff_date");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseLoggerFactory(loggerFactory);
        }

        readonly ILoggerFactory loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());

        public DbSet<Category> Category { get; set; }

        public DbSet<Product> Product { get; set; }

        // Define functions
        public int GetDiffDate(DateTime date) => throw new NotSupportedException();

        public IQueryable<CategoryDto> GetCategoryById(int categoryId) => FromExpression(() => GetCategoryById(categoryId));

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            IEnumerable<EntityEntry> modified = ChangeTracker.Entries()
                                                             .Where(e => e.State == EntityState.Modified || e.State == EntityState.Added);
            foreach (EntityEntry item in modified)
            {
                if (item.Entity is ITracking changedOrAddedItem)
                {
                    if (item.State == EntityState.Added)
                    {
                        changedOrAddedItem.CreatedDate = DateTime.Now;
                    }
                    else
                    {
                        changedOrAddedItem.UpdatedDate = DateTime.Now;
                    }
                }
            }
            return base.SaveChangesAsync(cancellationToken);
        }
    }
    public class DemoContextFactory : IDesignTimeDbContextFactory<DemoContext>
    {
        public DemoContext CreateDbContext(string[] args)
        {
            IConfiguration configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();
            var connectionString = configuration.GetConnectionString("DefaultConnection");
            var optionsBuilder = new DbContextOptionsBuilder<DemoContext>();
            optionsBuilder.UseSqlServer(connectionString, o => o.MigrationsAssembly("Demo.Data.EF"));

            return new DemoContext(optionsBuilder.Options);
        }
    }

}
